"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import Script from "next/script";
import { usePathname } from "next/navigation";
/**
 * GlobalAnalytics Component
 * Injects Google Analytics, Microsoft Clarity, Facebook Pixel, LinkedIn Insight Tag,
 * Google Tag Manager, and custom scripts dynamically from Global Settings.
 * Analytics and marketing scripts respect the cookie consent object saved by
 * the Global Backend cookie banner.
 */
function getConsentState(complianceSettings) {
  const consentRequired = complianceSettings?.cookieConsentEnabled === true;

  if (!consentRequired) {
    return { analytics: true, marketing: true };
  }

  if (typeof window === "undefined") {
    return { analytics: false, marketing: false };
  }

  try {
    const stored = JSON.parse(localStorage.getItem("cookie_consent") || "null");
    return {
      analytics: stored?.analytics === true,
      marketing: stored?.marketing === true,
    };
  } catch {
    return { analytics: false, marketing: false };
  }
}

/**
 * CtaPopups Component
 * Renders database-driven CTA popup modals on the public frontend.
 * Supports trigger types:
 *   - "page-load"   → shows after triggerValue seconds delay
 *   - "scroll"      → shows when user scrolls past triggerValue % of page height
 *   - "exit-intent" → shows when cursor leaves the viewport from the top
 * showOnce flag prevents re-showing via localStorage.
 */
export function CtaPopups({ ctaConfig }) {
  const popups = ctaConfig?.popups || [];
  const [visiblePopupId, setVisiblePopupId] = useState(null);
  const shownRef = useRef(new Set());

  const showPopup = useCallback(
    (id) => {
      if (shownRef.current.has(id)) return;
      const popup = popups.find((p) => p.id === id);
      if (!popup) return;
      if (popup.showOnce) {
        try {
          const key = `cta_popup_shown_${id}`;
          if (localStorage.getItem(key)) return;
          localStorage.setItem(key, "1");
        } catch {}
      }
      shownRef.current.add(id);
      setVisiblePopupId(id);
    },
    [popups]
  );

  useEffect(() => {
    if (!popups.length) return;
    const cleanups = [];
    popups.forEach((popup) => {
      if (!popup.id) return;
      if (popup.triggerOn === "page-load") {
        const delaySec = parseFloat(popup.triggerValue) || 0;
        const t = setTimeout(() => showPopup(popup.id), delaySec * 1000);
        cleanups.push(() => clearTimeout(t));
      } else if (popup.triggerOn === "scroll") {
        const pct = parseFloat(popup.triggerValue) || 50;
        const onScroll = () => {
          const scrollHeight = document.body.scrollHeight - window.innerHeight;
          if (scrollHeight <= 0) return;
          const scrolled = (window.scrollY / scrollHeight) * 100;
          if (scrolled >= pct) showPopup(popup.id);
        };
        window.addEventListener("scroll", onScroll, { passive: true });
        cleanups.push(() => window.removeEventListener("scroll", onScroll));
      } else if (popup.triggerOn === "exit-intent") {
        const onMouse = (e) => {
          if (e.clientY <= 10) showPopup(popup.id);
        };
        document.addEventListener("mouseleave", onMouse);
        cleanups.push(() => document.removeEventListener("mouseleave", onMouse));
      }
    });
    return () => cleanups.forEach((fn) => fn());
  }, [popups, showPopup]);

  const activePopup = popups.find((p) => p.id === visiblePopupId);
  if (!activePopup) return null;

  const typeMeta = {
    information: { accentColor: "#3b82f6", icon: "\u2139\ufe0f" },
    warning:     { accentColor: "#f59e0b", icon: "\u26a0\ufe0f" },
    promotional: { accentColor: "#8b5cf6", icon: "\uD83C\uDF81" },
    newsletter:  { accentColor: "#10b981", icon: "\uD83D\uDCEC" },
    urgent:      { accentColor: "#ef4444", icon: "\uD83D\uDEA8" },
  };
  const meta = typeMeta[activePopup.type] || typeMeta.information;

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes sdk-popup-fadein  { from { opacity:0 } to { opacity:1 } }
        @keyframes sdk-popup-slidein { from { opacity:0; transform:translateY(20px) scale(0.97) } to { opacity:1; transform:translateY(0) scale(1) } }
      ` }} />
      <div
        onClick={() => setVisiblePopupId(null)}
        style={{
          position:"fixed", inset:0, zIndex:9999,
          backgroundColor:"rgba(0,0,0,0.55)", backdropFilter:"blur(2px)",
          display:"flex", alignItems:"center", justifyContent:"center", padding:"1rem",
          animation:"sdk-popup-fadein 0.25s ease",
        }}
      >
        <div
          onClick={(e) => e.stopPropagation()}
          style={{
            backgroundColor:"#ffffff", borderRadius:"1rem",
            boxShadow:"0 20px 50px rgba(0,0,0,0.3)",
            maxWidth:"480px", width:"100%", overflow:"hidden", position:"relative",
            animation:"sdk-popup-slidein 0.25s ease",
          }}
        >
          <div style={{ height:"4px", backgroundColor:meta.accentColor }} />
          <button
            onClick={() => setVisiblePopupId(null)}
            aria-label="Close popup"
            style={{
              position:"absolute", top:"0.75rem", right:"0.75rem",
              background:"rgba(0,0,0,0.07)", border:"none", borderRadius:"50%",
              width:"28px", height:"28px", cursor:"pointer",
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:"1rem", color:"#374151", lineHeight:1, zIndex:10,
            }}
          >&#x00D7;</button>
          <div style={{ padding:"1.75rem 1.75rem 1.5rem" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"0.625rem", marginBottom:"0.75rem" }}>
              <span style={{ fontSize:"1.4rem" }}>{meta.icon}</span>
              <h2 style={{ margin:0, fontSize:"1.1rem", fontWeight:700, color:"#111827", lineHeight:1.3 }}>
                {activePopup.title}
              </h2>
            </div>
            {activePopup.body && (
              <p style={{ margin:"0 0 1.25rem", fontSize:"0.9rem", color:"#4b5563", lineHeight:1.6 }}>
                {activePopup.body}
              </p>
            )}
            {activePopup.buttonText && activePopup.buttonLink && (
              <a
                href={activePopup.buttonLink}
                onClick={() => setVisiblePopupId(null)}
                style={{
                  display:"inline-block", backgroundColor:meta.accentColor,
                  color:"#ffffff", padding:"0.625rem 1.25rem",
                  borderRadius:"0.5rem", fontSize:"0.875rem", fontWeight:600,
                  textDecoration:"none", transition:"opacity 0.15s ease",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.88")}
                onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
              >
                {activePopup.buttonText}
              </a>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

/**
 * CtaFloatingButtons Component
 * Renders database-driven floating action buttons at fixed screen positions.
 * Reads ctaConfig.floatingButtons[] and skips any with enabled === false.
 */
export function CtaFloatingButtons({ ctaConfig }) {
  const buttons = (ctaConfig?.floatingButtons || []).filter((b) => b.enabled !== false);
  if (!buttons.length) return null;

  const positionMap = {
    "bottom-right": { bottom:"1.5rem", right:"1.5rem" },
    "bottom-left":  { bottom:"1.5rem", left:"1.5rem"  },
    "top-right":    { top:"1.5rem",    right:"1.5rem" },
    "top-left":     { top:"1.5rem",    left:"1.5rem"  },
  };

  return (
    <>
      {buttons.map((btn) => {
        const pos = positionMap[btn.position] || positionMap["bottom-right"];
        return (
          <a
            key={btn.id}
            href={btn.link || "#"}
            aria-label={btn.label}
            title={btn.label}
            style={{
              position:"fixed", ...pos, zIndex:9000,
              display:"flex", alignItems:"center", gap:"0.5rem",
              backgroundColor:btn.color || "#1e293b", color:"#ffffff",
              padding:"0.625rem 1rem", borderRadius:"2rem",
              boxShadow:"0 4px 14px rgba(0,0,0,0.25)",
              textDecoration:"none", fontSize:"0.85rem", fontWeight:600,
              transition:"transform 0.2s ease, box-shadow 0.2s ease",
              whiteSpace:"nowrap",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-2px)";
              e.currentTarget.style.boxShadow = "0 6px 20px rgba(0,0,0,0.3)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.boxShadow = "0 4px 14px rgba(0,0,0,0.25)";
            }}
          >
            {btn.icon && <span style={{ fontSize:"1rem" }}>{btn.icon}</span>}
            {btn.label}
          </a>
        );
      })}
    </>
  );
}

export function GlobalAnalytics({ settings }) {
  const [consent, setConsent] = useState(() =>
    getConsentState(settings?.compliance || {}),
  );

  const pathname = usePathname();

  React.useEffect(() => {
    const updateConsent = () => {
      setConsent(getConsentState(settings?.compliance || {}));
    };

    updateConsent();
    window.addEventListener("storage", updateConsent);
    window.addEventListener("cookieConsentChanged", updateConsent);
    return () => {
      window.removeEventListener("storage", updateConsent);
      window.removeEventListener("cookieConsentChanged", updateConsent);
    };
  }, [settings?.compliance]);

  React.useEffect(() => {
    let visitorId = localStorage.getItem("visitor_id");
    if (!visitorId) {
      visitorId = `visitor_${Math.random().toString(36).substring(2, 11)}`;
      localStorage.setItem("visitor_id", visitorId);
    }

    const trackPageview = async () => {
      try {
        const resolvedBaseUrl = typeof window !== 'undefined' 
          ? window.location.origin 
          : (process.env.NEXT_PUBLIC_CMS_BASE_URL || "http://localhost:3000");
        const resolvedSiteId = process.env.NEXT_PUBLIC_SITE_ID || "infinium";
        const deviceInfo = typeof navigator !== "undefined" ? navigator.userAgent : "Unknown";
        const trafficSource = typeof document !== "undefined" ? document.referrer : "";

        await fetch(
          `${resolvedBaseUrl.replace(/\/$/, "")}/api/visitors/ping`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              siteId: resolvedSiteId,
              visitorId,
              pageViewed: pathname || "/",
              deviceInfo,
              trafficSource,
              location: "Local Session",
            }),
          },
        );
      } catch (err) {
        console.error("Failed to track visitor pageview:", err);
      }
    };

    trackPageview();
  }, [pathname]);

  if (!settings) return null;

  const analytics = settings.analytics || {};
  const scripts = settings.scripts || {};
  const gaId = analytics.gaMeasurementId || analytics.googleAnalyticsId;
  const gtmId = analytics.gtmId || analytics.googleTagManagerId;
  const searchConsoleVerification =
    analytics.searchConsoleVerification || analytics.searchConsoleId;
  const linkedinId = analytics.linkedInTagId || analytics.linkedinPartnerId;

  return (
    <>
      {/* Raw HTML Head Scripts Injection */}
      {consent.analytics && scripts.head && (
        <span
          style={{ display: "none" }}
          dangerouslySetInnerHTML={{
            __html: `<!-- Head Scripts -->\n${scripts.head}`,
          }}
        />
      )}

      {/* Google Search Console verification */}
      {searchConsoleVerification && (
        <meta
          name="google-site-verification"
          content={searchConsoleVerification}
        />
      )}

      {/* Google Tag Manager */}
      {consent.analytics && gtmId && (
        <Script id="gtm-script" strategy="afterInteractive">
          {`(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','${gtmId}');`}
        </Script>
      )}

      {/* Google Analytics 4 */}
      {consent.analytics && gaId && (
        <>
          <Script
            strategy="afterInteractive"
            src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
          />
          <Script id="ga4-script" strategy="afterInteractive">
            {`window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${gaId}');`}
          </Script>
        </>
      )}

      {/* Microsoft Clarity */}
      {consent.analytics && analytics.clarityId && (
        <Script id="clarity-script" strategy="afterInteractive">
          {`(function(c,l,a,r,i,t,y){
              c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
              t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
              y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
          })(window, document, "clarity", "script", "${analytics.clarityId}");`}
        </Script>
      )}

      {/* Facebook Meta Pixel */}
      {consent.marketing && analytics.metaPixelId && (
        <>
          <Script id="meta-pixel-script" strategy="afterInteractive">
            {`!function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '${analytics.metaPixelId}');
            fbq('track', 'PageView');`}
          </Script>
          <noscript>
            <img
              height="1"
              width="1"
              style={{ display: "none" }}
              src={`https://www.facebook.com/tr?id=${analytics.metaPixelId}&ev=PageView&noscript=1`}
              alt=""
            />
          </noscript>
        </>
      )}

      {/* LinkedIn Insight Tag */}
      {consent.marketing && linkedinId && (
        <>
          <Script id="linkedin-insight-script" strategy="afterInteractive">
            {`_linkedin_partner_id = "${linkedinId}";
            window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
            window._linkedin_data_partner_ids.push(_linkedin_partner_id);
            (function(l) {
            if (!l) {window._linkedin_data_partner_script_loaded = true;
            var d = document; var s = d.getElementsByTagName("script")[0];
            var b = d.createElement("script");
            b.type = "text/javascript";b.async = true;
            b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
            s.parentNode.insertBefore(b, s);}})(window._linkedin_data_partner_ids[0]);`}
          </Script>
          <noscript>
            <img
              height="1"
              width="1"
              style={{ display: "none" }}
              src={`https://px.ads.linkedin.com/collect/?pid=${linkedinId}&fmt=gif`}
              alt=""
            />
          </noscript>
        </>
      )}

      {/* Raw HTML Body Scripts Injection */}
      {consent.analytics && scripts.body && (
        <span
          style={{ display: "none" }}
          dangerouslySetInnerHTML={{
            __html: `<!-- Body Scripts -->\n${scripts.body}`,
          }}
        />
      )}
    </>
  );
}

export function CookieConsentBanner({ complianceSettings, siteId, baseUrl }) {
  const [showBanner, setShowBanner] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [analyticsAccepted, setAnalyticsAccepted] = useState(
    complianceSettings?.analyticsCookiesEnabled ?? true,
  );
  const [marketingAccepted, setMarketingAccepted] = useState(
    complianceSettings?.marketingCookiesEnabled ?? true,
  );

  const {
    cookieConsentEnabled = false,
    cookieConsentMessage = "This website uses cookies to improve your experience.",
    bannerPosition = "bottom",
    acceptButtonText = "Accept All",
    declineButtonText = "Decline",
    settingsButtonText = "Preferences",
    analyticsCookiesEnabled = true,
    marketingCookiesEnabled = true,
  } = complianceSettings || {};

  React.useEffect(() => {
    if (!cookieConsentEnabled) return;

    const storedConsent = localStorage.getItem("cookie_consent");
    if (!storedConsent) {
      const timer = window.setTimeout(() => setShowBanner(true), 0);
      return () => window.clearTimeout(timer);
    }
  }, [cookieConsentEnabled]);

  const logConsent = async (consentType, accepted, visitorId) => {
    try {
      const resolvedBaseUrl =
        baseUrl ||
        process.env.NEXT_PUBLIC_CMS_BASE_URL ||
        "http://localhost:3000";
      const resolvedSiteId =
        siteId || process.env.NEXT_PUBLIC_SITE_ID || "layman_litigation";

      await fetch(
        `${resolvedBaseUrl.replace(/\/$/, "")}/api/compliance/consent`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            siteId: resolvedSiteId,
            visitorId,
            consentType,
            accepted,
          }),
        },
      );
    } catch (err) {
      console.error("Failed to log consent to backend:", err);
    }
  };

  const saveConsent = async ({ analytics, marketing }) => {
    const visitorId =
      localStorage.getItem("visitor_id") ||
      `visitor_${Math.random().toString(36).slice(2, 11)}`;
    localStorage.setItem("visitor_id", visitorId);

    const consentData = {
      essential: true,
      analytics,
      marketing,
      timestamp: new Date().toISOString(),
    };

    localStorage.setItem("cookie_consent", JSON.stringify(consentData));
    setShowBanner(false);
    setShowPreferences(false);

    await Promise.all([
      logConsent("essential", true, visitorId),
      logConsent("analytics", analytics, visitorId),
      logConsent("marketing", marketing, visitorId),
    ]);

    window.dispatchEvent(new Event("cookieConsentChanged"));
  };

  if (!showBanner) return null;

  const bannerInlineStyle = (() => {
    const base = {
      position: "fixed",
      zIndex: 9999,
      backgroundColor: "var(--ll-cream)",
      border: "1px solid var(--ll-stone)",
      borderRadius: "1rem",
      padding: "20px",
      boxShadow: "var(--ll-shadow-lift)",
      display: "flex",
      flexDirection: "column",
      gap: "16px",
      width: "360px",
      maxWidth: "calc(100vw - 32px)",
      color: "var(--ll-ink)",
    };
    if (bannerPosition === "top") {
      return { ...base, top: "24px", right: "24px" };
    } else if (bannerPosition === "popup") {
      return { ...base, top: "50%", left: "50%", transform: "translate(-50%, -50%)", width: "90%", maxWidth: "380px" };
    } else {
      return { ...base, bottom: "24px", right: "24px" };
    }
  })();

  return (
    <div style={bannerInlineStyle}>
      <div className="flex items-start gap-3">
        {/* Cookie SVG Icon */}
        <div className="p-2 bg-[var(--ll-gold-light)] border border-[var(--ll-gold)]/20 rounded-lg text-[var(--ll-gold-dark)] shrink-0 mt-0.5">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m0-11.314l.707.707m11.314 11.314l.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" />
          </svg>
        </div>
        <div className="space-y-1">
          <h4 className="text-sm font-extrabold text-[var(--ll-ink)] tracking-tight">Cookie Consent</h4>
          <p className="text-sm text-[var(--ll-slate-text)] max-w-4xl leading-relaxed">
            {cookieConsentMessage}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-end gap-2 border-t border-[var(--ll-stone)] pt-3">
        <button
          type="button"
          onClick={() => setShowPreferences((value) => !value)}
          className="px-4 py-2.5 rounded-[var(--ll-radius-sm)] bg-transparent text-[var(--ll-slate-text)] hover:text-[var(--ll-ink)] font-semibold text-sm hover:bg-[var(--ll-stone)] transition-all cursor-pointer"
        >
          {settingsButtonText}
        </button>
        <button
          type="button"
          onClick={() => saveConsent({ analytics: false, marketing: false })}
          className="px-4 py-2.5 rounded-[var(--ll-radius-sm)] bg-transparent text-[var(--ll-slate-text)] hover:text-[var(--ll-ink)] font-semibold text-sm hover:bg-[var(--ll-stone)] transition-all cursor-pointer"
        >
          {declineButtonText}
        </button>
        <button
          type="button"
          onClick={() =>
            saveConsent({
              analytics: analyticsCookiesEnabled,
              marketing: marketingCookiesEnabled,
            })
          }
          className="px-7 py-3.5 rounded-[var(--ll-radius-sm)] bg-[var(--ll-gold)] hover:bg-[var(--ll-gold-dark)] text-[var(--ll-ink)] font-bold text-sm tracking-wide shadow-sm transition-all duration-200 hover:-translate-y-px active:translate-y-0 cursor-pointer"
        >
          {acceptButtonText}
        </button>
      </div>

      {showPreferences && (
        <div className="mt-1 flex flex-col gap-3 border-t border-[var(--ll-stone)] pt-3 text-xs text-neutral-300 animate-in fade-in duration-200">
          <label className="flex items-center justify-between gap-4 p-2 bg-[var(--ll-mist)] border border-[var(--ll-stone)] rounded-xl cursor-pointer">
            <span className="font-medium text-[var(--ll-ink)]">Essential cookies</span>
            <input type="checkbox" checked readOnly className="accent-[var(--ll-gold)] rounded" />
          </label>
          {analyticsCookiesEnabled && (
            <label className="flex items-center justify-between gap-4 p-2 bg-[var(--ll-mist)] border border-[var(--ll-stone)] rounded-xl cursor-pointer hover:bg-[var(--ll-stone)]/50 transition-colors">
              <span className="font-medium text-[var(--ll-ink)]">Analytics cookies</span>
              <input
                type="checkbox"
                checked={analyticsAccepted}
                onChange={(e) => setAnalyticsAccepted(e.target.checked)}
                className="accent-[var(--ll-gold)] rounded"
              />
            </label>
          )}
          {marketingCookiesEnabled && (
            <label className="flex items-center justify-between gap-4 p-2 bg-[var(--ll-mist)] border border-[var(--ll-stone)] rounded-xl cursor-pointer hover:bg-[var(--ll-stone)]/50 transition-colors">
              <span className="font-medium text-[var(--ll-ink)]">Marketing cookies</span>
              <input
                type="checkbox"
                checked={marketingAccepted}
                onChange={(e) => setMarketingAccepted(e.target.checked)}
                className="accent-[var(--ll-gold)] rounded"
              />
            </label>
          )}
          <button
            type="button"
            onClick={() =>
              saveConsent({
                analytics: analyticsCookiesEnabled && analyticsAccepted,
                marketing: marketingCookiesEnabled && marketingAccepted,
              })
            }
            className="w-full py-2.5 bg-[var(--ll-gold)] hover:bg-[var(--ll-gold-dark)] text-[var(--ll-ink)] rounded-[var(--ll-radius-sm)] font-bold text-xs shadow-md transition-all cursor-pointer hover:-translate-y-px text-center mt-1"
          >
            Save Preferences
          </button>
        </div>
      )}
    </div>
  );
}

/**
 * Helper SVG components
 */
function HamburgerIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ display: "block" }}
    >
      <line x1="4" x2="20" y1="12" y2="12" />
      <line x1="4" x2="20" y1="6" y2="6" />
      <line x1="4" x2="20" y1="18" y2="18" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ display: "block" }}
    >
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

/**
 * Plug-and-Play Navigation Header Component
 */
export function Header({
  logoUrl,
  siteName,
  headerSettings = {},
  navigationLinks = [],
}) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [expandedMobileItems, setExpandedMobileItems] = React.useState(
    new Set(),
  );

  // Merge defaults
  const config = {
    layout: "logo-left",
    logoType: "image",
    logoText: siteName || "MySite",
    logoUrl: logoUrl || "/next.svg",
    logoWidth: 120,
    logoHeight: 40,
    sticky: true,
    transparent: false,
    paddingY: "medium",
    borderBottom: true,
    shadowSize: "small",
    ctaText: "",
    ctaLink: "",
    bgColor: "#ffffff",
    textColor: "#4a5568",
    announcementBar: {
      enabled: false,
      text: "",
      link: "",
      bgColor: "#2563eb",
      textColor: "#ffffff",
    },
    mobileDrawerStyle: "slide-left",
    mobileDrawerBg: "#ffffff",
    mobileDrawerTextColor: "#1a202c",
    ...headerSettings,
  };

  const isSticky = config.sticky;
  const isTransparent = config.transparent;

  // Padding Y style values
  let paddingYVal = "1rem";
  if (config.paddingY === "small") paddingYVal = "0.5rem";
  if (config.paddingY === "large") paddingYVal = "1.5rem";

  // Shadow Size style values
  let shadowVal = "none";
  if (config.shadowSize === "small")
    shadowVal = "0 1px 2px 0 rgba(0, 0, 0, 0.05)";
  if (config.shadowSize === "medium")
    shadowVal =
      "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)";

  const headerStyle = {
    backgroundColor: isTransparent
      ? "transparent"
      : config.bgColor || "#ffffff",
    borderBottom: config.borderBottom ? "1px solid #e2e8f0" : "none",
    width: "100%",
    zIndex: 50,
    position: isSticky ? "sticky" : "relative",
    top: 0,
    boxShadow: shadowVal,
    transition: "all 0.3s ease",
  };

  const navContainerStyle = {
    maxWidth: "80rem",
    margin: "0 auto",
    padding: `${paddingYVal} 1.5rem`,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    position: "relative",
  };

  const navLinksStyle = {
    display: "flex",
    gap: "1.5rem",
    fontSize: "0.85rem",
    fontWeight: 600,
    color: config.textColor || "#4a5568",
    alignItems: "center",
  };

  const renderLogo = () => {
    if (config.logoType === "text") {
      return (
        <span
          style={{
            fontSize: "1.25rem",
            fontWeight: 800,
            color: config.textColor || "#1a202c",
          }}
        >
          {config.logoText}
        </span>
      );
    }
    return (
      <img
        src={config.logoUrl}
        alt="Logo"
        style={{
          width: config.logoWidth ? `${config.logoWidth}px` : "auto",
          height: config.logoHeight ? `${config.logoHeight}px` : "auto",
          objectFit: "contain",
        }}
      />
    );
  };

  let leftLinks = [];
  let rightLinks = [];
  if (config.layout === "logo-split") {
    const mid = Math.ceil(navigationLinks.length / 2);
    leftLinks = navigationLinks.slice(0, mid);
    rightLinks = navigationLinks.slice(mid);
  }

  const ctaBtnStyle = {
    padding: "0.5rem 1rem",
    backgroundColor: "#4f46e5",
    color: "#ffffff",
    borderRadius: "0.375rem",
    fontSize: "0.85rem",
    fontWeight: 600,
    textDecoration: "none",
    boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
    display: "inline-block",
  };

  const announcementBarStyle = {
    backgroundColor: config.announcementBar?.bgColor || "#2563eb",
    color: config.announcementBar?.textColor || "#ffffff",
    padding: "0.5rem 1rem",
    textAlign: "center",
    fontSize: "0.75rem",
    fontWeight: 600,
    width: "100%",
    display: "block",
    textDecoration: "none",
  };

  const renderHeaderContent = () => {
    switch (config.layout) {
      case "logo-center":
        return (
          <>
            <nav style={navLinksStyle} className="sdk-desktop-only">
              {navigationLinks.map((link, idx) => {
                const hasChildren = link.children && link.children.length > 0;
                return hasChildren ? (
                  <div
                    key={idx}
                    className="sdk-dropdown-wrapper"
                    style={{ position: "relative", display: "inline-block" }}
                  >
                    <a
                      href={link.url}
                      style={{
                        textDecoration: "none",
                        color: "inherit",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      {link.label}
                      <svg
                        width="10"
                        height="10"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </a>
                    <div
                      className="sdk-dropdown-menu"
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: "0",
                        marginTop: "12px",
                        backgroundColor: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                        minWidth: "200px",
                        padding: "8px",
                        opacity: 0,
                        pointerEvents: "none",
                        transform: "translateY(4px)",
                        transition: "all 0.2s ease",
                        zIndex: 100,
                      }}
                    >
                      {link.children.map((child, cIdx) => (
                        <a
                          key={cIdx}
                          href={child.url}
                          style={{
                            textDecoration: "none",
                            color: "#4a5568",
                            display: "block",
                            padding: "8px 12px",
                            borderRadius: "6px",
                            fontSize: "0.85rem",
                            fontWeight: 500,
                          }}
                          className="sdk-dropdown-item"
                        >
                          {child.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a
                    key={idx}
                    href={link.url}
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    {link.label}
                  </a>
                );
              })}
            </nav>
            <div
              style={{
                position: "absolute",
                left: "50%",
                transform: "translateX(-50%)",
              }}
            >
              {renderLogo()}
            </div>
            <div className="sdk-desktop-only">
              {config.ctaText && config.ctaLink && (
                <a href={config.ctaLink} style={ctaBtnStyle}>
                  {config.ctaText}
                </a>
              )}
            </div>
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="sdk-hamburger-btn"
              aria-label="Open menu"
            >
              <HamburgerIcon />
            </button>
          </>
        );

      case "logo-split":
        return (
          <div
            style={{
              display: "flex",
              width: "100%",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <nav style={navLinksStyle} className="sdk-desktop-only">
              {leftLinks.map((link, idx) => {
                const hasChildren = link.children && link.children.length > 0;
                return hasChildren ? (
                  <div
                    key={idx}
                    className="sdk-dropdown-wrapper"
                    style={{ position: "relative", display: "inline-block" }}
                  >
                    <a
                      href={link.url}
                      style={{
                        textDecoration: "none",
                        color: "inherit",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      {link.label}
                      <svg
                        width="10"
                        height="10"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </a>
                    <div
                      className="sdk-dropdown-menu"
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: "0",
                        marginTop: "12px",
                        backgroundColor: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                        minWidth: "200px",
                        padding: "8px",
                        opacity: 0,
                        pointerEvents: "none",
                        transform: "translateY(4px)",
                        transition: "all 0.2s ease",
                        zIndex: 100,
                      }}
                    >
                      {link.children.map((child, cIdx) => (
                        <a
                          key={cIdx}
                          href={child.url}
                          style={{
                            textDecoration: "none",
                            color: "#4a5568",
                            display: "block",
                            padding: "8px 12px",
                            borderRadius: "6px",
                            fontSize: "0.85rem",
                            fontWeight: 500,
                          }}
                          className="sdk-dropdown-item"
                        >
                          {child.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a
                    key={idx}
                    href={link.url}
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    {link.label}
                  </a>
                );
              })}
            </nav>
            <div>{renderLogo()}</div>
            <nav style={navLinksStyle} className="sdk-desktop-only">
              {rightLinks.map((link, idx) => {
                const hasChildren = link.children && link.children.length > 0;
                return hasChildren ? (
                  <div
                    key={idx}
                    className="sdk-dropdown-wrapper"
                    style={{ position: "relative", display: "inline-block" }}
                  >
                    <a
                      href={link.url}
                      style={{
                        textDecoration: "none",
                        color: "inherit",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      {link.label}
                      <svg
                        width="10"
                        height="10"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </a>
                    <div
                      className="sdk-dropdown-menu"
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: "0",
                        marginTop: "12px",
                        backgroundColor: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                        minWidth: "200px",
                        padding: "8px",
                        opacity: 0,
                        pointerEvents: "none",
                        transform: "translateY(4px)",
                        transition: "all 0.2s ease",
                        zIndex: 100,
                      }}
                    >
                      {link.children.map((child, cIdx) => (
                        <a
                          key={cIdx}
                          href={child.url}
                          style={{
                            textDecoration: "none",
                            color: "#4a5568",
                            display: "block",
                            padding: "8px 12px",
                            borderRadius: "6px",
                            fontSize: "0.85rem",
                            fontWeight: 500,
                          }}
                          className="sdk-dropdown-item"
                        >
                          {child.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a
                    key={idx}
                    href={link.url}
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    {link.label}
                  </a>
                );
              })}
            </nav>
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="sdk-hamburger-btn"
              aria-label="Open menu"
            >
              <HamburgerIcon />
            </button>
          </div>
        );

      case "logo-right":
        return (
          <>
            <div className="sdk-desktop-only">
              {config.ctaText && config.ctaLink && (
                <a href={config.ctaLink} style={ctaBtnStyle}>
                  {config.ctaText}
                </a>
              )}
            </div>
            <nav style={navLinksStyle} className="sdk-desktop-only">
              {navigationLinks.map((link, idx) => {
                const hasChildren = link.children && link.children.length > 0;
                return hasChildren ? (
                  <div
                    key={idx}
                    className="sdk-dropdown-wrapper"
                    style={{ position: "relative", display: "inline-block" }}
                  >
                    <a
                      href={link.url}
                      style={{
                        textDecoration: "none",
                        color: "inherit",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      {link.label}
                      <svg
                        width="10"
                        height="10"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </a>
                    <div
                      className="sdk-dropdown-menu"
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: "0",
                        marginTop: "12px",
                        backgroundColor: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                        minWidth: "200px",
                        padding: "8px",
                        opacity: 0,
                        pointerEvents: "none",
                        transform: "translateY(4px)",
                        transition: "all 0.2s ease",
                        zIndex: 100,
                      }}
                    >
                      {link.children.map((child, cIdx) => (
                        <a
                          key={cIdx}
                          href={child.url}
                          style={{
                            textDecoration: "none",
                            color: "#4a5568",
                            display: "block",
                            padding: "8px 12px",
                            borderRadius: "6px",
                            fontSize: "0.85rem",
                            fontWeight: 500,
                          }}
                          className="sdk-dropdown-item"
                        >
                          {child.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a
                    key={idx}
                    href={link.url}
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    {link.label}
                  </a>
                );
              })}
            </nav>
            <div>{renderLogo()}</div>
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="sdk-hamburger-btn"
              aria-label="Open menu"
            >
              <HamburgerIcon />
            </button>
          </>
        );

      case "stacked":
        return (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              width: "100%",
              alignItems: "center",
              gap: "1rem",
            }}
          >
            <div
              style={{
                display: "flex",
                width: "100%",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div>{renderLogo()}</div>
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className="sdk-hamburger-btn"
                aria-label="Open menu"
              >
                <HamburgerIcon />
              </button>
            </div>
            <div
              className="sdk-desktop-only"
              style={{
                display: "flex",
                width: "100%",
                justifyContent: "space-between",
                alignItems: "center",
                borderTop: "1px solid #f1f5f9",
                paddingTop: "0.75rem",
              }}
            >
              <nav style={navLinksStyle}>
                {navigationLinks.map((link, idx) => {
                  const hasChildren = link.children && link.children.length > 0;
                  return hasChildren ? (
                    <div
                      key={idx}
                      className="sdk-dropdown-wrapper"
                      style={{ position: "relative", display: "inline-block" }}
                    >
                      <a
                        href={link.url}
                        style={{
                          textDecoration: "none",
                          color: "inherit",
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          gap: "4px",
                        }}
                      >
                        {link.label}
                        <svg
                          width="10"
                          height="10"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <polyline points="6 9 12 15 18 9" />
                        </svg>
                      </a>
                      <div
                        className="sdk-dropdown-menu"
                        style={{
                          position: "absolute",
                          top: "100%",
                          left: "0",
                          marginTop: "12px",
                          backgroundColor: "#ffffff",
                          border: "1px solid #e2e8f0",
                          borderRadius: "8px",
                          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                          minWidth: "200px",
                          padding: "8px",
                          opacity: 0,
                          pointerEvents: "none",
                          transform: "translateY(4px)",
                          transition: "all 0.2s ease",
                          zIndex: 100,
                        }}
                      >
                        {link.children.map((child, cIdx) => (
                          <a
                            key={cIdx}
                            href={child.url}
                            style={{
                              textDecoration: "none",
                              color: "#4a5568",
                              display: "block",
                              padding: "8px 12px",
                              borderRadius: "6px",
                              fontSize: "0.85rem",
                              fontWeight: 500,
                            }}
                            className="sdk-dropdown-item"
                          >
                            {child.label}
                          </a>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <a
                      key={idx}
                      href={link.url}
                      style={{ textDecoration: "none", color: "inherit" }}
                    >
                      {link.label}
                    </a>
                  );
                })}
              </nav>
              <div>
                {config.ctaText && config.ctaLink && (
                  <a href={config.ctaLink} style={ctaBtnStyle}>
                    {config.ctaText}
                  </a>
                )}
              </div>
            </div>
          </div>
        );

      case "logo-left":
      default:
        return (
          <>
            <div
              style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}
            >
              {renderLogo()}
            </div>
            <nav style={navLinksStyle} className="sdk-desktop-only">
              {navigationLinks.map((link, idx) => {
                const hasChildren = link.children && link.children.length > 0;
                return hasChildren ? (
                  <div
                    key={idx}
                    className="sdk-dropdown-wrapper"
                    style={{ position: "relative", display: "inline-block" }}
                  >
                    <a
                      href={link.url}
                      style={{
                        textDecoration: "none",
                        color: "inherit",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                      }}
                    >
                      {link.label}
                      <svg
                        width="10"
                        height="10"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </a>
                    <div
                      className="sdk-dropdown-menu"
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: "0",
                        marginTop: "12px",
                        backgroundColor: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                        minWidth: "200px",
                        padding: "8px",
                        opacity: 0,
                        pointerEvents: "none",
                        transform: "translateY(4px)",
                        transition: "all 0.2s ease",
                        zIndex: 100,
                      }}
                    >
                      {link.children.map((child, cIdx) => (
                        <a
                          key={cIdx}
                          href={child.url}
                          style={{
                            textDecoration: "none",
                            color: "#4a5568",
                            display: "block",
                            padding: "8px 12px",
                            borderRadius: "6px",
                            fontSize: "0.85rem",
                            fontWeight: 500,
                          }}
                          className="sdk-dropdown-item"
                        >
                          {child.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a
                    key={idx}
                    href={link.url}
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    {link.label}
                  </a>
                );
              })}
              {config.ctaText && config.ctaLink && (
                <a
                  href={config.ctaLink}
                  style={{ ...ctaBtnStyle, marginLeft: "1rem" }}
                >
                  {config.ctaText}
                </a>
              )}
            </nav>
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="sdk-hamburger-btn"
              aria-label="Open menu"
            >
              <HamburgerIcon />
            </button>
          </>
        );
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", width: "100%" }}>
      <style
        dangerouslySetInnerHTML={{
          __html: `
        .sdk-desktop-only {
          display: flex !important;
        }
        .sdk-mobile-only {
          display: none !important;
        }
        @media (max-width: 768px) {
          .sdk-desktop-only {
            display: none !important;
          }
          .sdk-mobile-only {
            display: flex !important;
          }
        }

        .sdk-hamburger-btn {
          display: none;
          align-items: center;
          justify-content: center;
          background: none;
          border: none;
          cursor: pointer;
          padding: 0.5rem;
          color: ${config.textColor || "#4a5568"};
        }
        @media (max-width: 768px) {
          .sdk-hamburger-btn {
            display: flex;
          }
        }

        .sdk-drawer-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100vh;
          background-color: rgba(0, 0, 0, 0.4);
          z-index: 999;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s ease;
        }
        .sdk-drawer-overlay.open {
          opacity: 1;
          pointer-events: auto;
        }

        .sdk-drawer {
          position: fixed;
          top: 0;
          height: 100vh;
          width: 300px;
          max-width: 80%;
          background-color: ${config.mobileDrawerBg || "#ffffff"};
          color: ${config.mobileDrawerTextColor || "#1a202c"};
          z-index: 1000;
          box-shadow: -2px 0 10px rgba(0,0,0,0.1);
          padding: 2rem;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
          transition: transform 0.3s ease, opacity 0.3s ease;
        }

        .sdk-drawer.style-slide-left {
          left: 0;
          transform: translateX(-100%);
        }
        .sdk-drawer.style-slide-left.open {
          transform: translateX(0);
        }

        .sdk-drawer.style-slide-right {
          right: 0;
          transform: translateX(100%);
        }
        .sdk-drawer.style-slide-right.open {
          transform: translateX(0);
        }

        .sdk-drawer.style-fade {
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%) scale(0.9);
          height: auto;
          max-height: 85vh;
          border-radius: 0.5rem;
          opacity: 0;
          pointer-events: none;
          box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        .sdk-drawer.style-fade.open {
          opacity: 1;
          transform: translate(-50%, -50%) scale(1);
          pointer-events: auto;
        }

        .sdk-drawer-close {
          align-self: flex-end;
          background: none;
          border: none;
          cursor: pointer;
          font-size: 1.5rem;
          color: inherit;
          padding: 0.5rem;
          line-height: 1;
        }

        .sdk-drawer-nav {
          display: flex;
          flex-direction: column;
          gap: 1.25rem;
        }
        .sdk-drawer-link {
          text-decoration: none;
          color: inherit;
          font-size: 1.1rem;
          font-weight: 500;
          transition: opacity 0.2s;
        }
        .sdk-drawer-link:hover {
          opacity: 0.8;
        }

        .sdk-dropdown-wrapper {
          position: relative !important;
          display: inline-block !important;
        }
        .sdk-dropdown-wrapper::after {
          content: '';
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          height: 12px;
        }
        .sdk-dropdown-wrapper:hover .sdk-dropdown-menu {
          opacity: 1 !important;
          pointer-events: auto !important;
          transform: translateY(0) !important;
        }
        .sdk-dropdown-item:hover {
          background-color: #f7fafc !important;
        }
      `,
        }}
      />

      {config.announcementBar?.enabled && config.announcementBar?.text && (
        <a
          href={config.announcementBar.link || "#"}
          style={announcementBarStyle}
        >
          {config.announcementBar.text}
        </a>
      )}
      <header style={headerStyle}>
        <div style={navContainerStyle}>{renderHeaderContent()}</div>
      </header>

      {/* Mobile Drawer Overlay */}
      <div
        className={`sdk-drawer-overlay ${isMobileMenuOpen ? "open" : ""}`}
        onClick={() => setIsMobileMenuOpen(false)}
      />

      {/* Mobile Drawer Container */}
      <div
        className={`sdk-drawer style-${config.mobileDrawerStyle || "slide-left"} ${isMobileMenuOpen ? "open" : ""}`}
        style={{
          backgroundColor: config.mobileDrawerBg || "#ffffff",
          color: config.mobileDrawerTextColor || "#1a202c",
        }}
      >
        <button
          onClick={() => setIsMobileMenuOpen(false)}
          className="sdk-drawer-close"
          aria-label="Close menu"
        >
          <CloseIcon />
        </button>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
            marginBottom: "1rem",
          }}
        >
          {renderLogo()}
        </div>
        <nav className="sdk-drawer-nav">
          {navigationLinks.map((link, idx) => {
            const hasChildren = link.children && link.children.length > 0;
            const isExpanded = expandedMobileItems.has(idx);
            return (
              <div key={idx}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <a
                    href={link.url}
                    className="sdk-drawer-link"
                    onClick={() => setIsMobileMenuOpen(false)}
                    style={{ flex: 1 }}
                  >
                    {link.label}
                  </a>
                  {hasChildren && (
                    <button
                      onClick={() => {
                        const next = new Set(expandedMobileItems);
                        if (isExpanded) next.delete(idx);
                        else next.add(idx);
                        setExpandedMobileItems(next);
                      }}
                      style={{
                        background: "none",
                        border: "none",
                        cursor: "pointer",
                        padding: "8px",
                        color: "inherit",
                      }}
                    >
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        style={{
                          transform: isExpanded ? "rotate(180deg)" : "none",
                          transition: "transform 0.2s",
                        }}
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </button>
                  )}
                </div>
                {hasChildren && isExpanded && (
                  <div
                    style={{
                      marginLeft: "16px",
                      borderLeft: "2px solid #e2e8f0",
                      paddingLeft: "12px",
                      display: "flex",
                      flexDirection: "column",
                      gap: "12px",
                      marginTop: "8px",
                    }}
                  >
                    {link.children.map((child, cIdx) => (
                      <a
                        key={cIdx}
                        href={child.url}
                        className="sdk-drawer-link"
                        onClick={() => setIsMobileMenuOpen(false)}
                        style={{ fontSize: "0.95rem" }}
                      >
                        {child.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
          {config.ctaText && config.ctaLink && (
            <a
              href={config.ctaLink}
              style={{ ...ctaBtnStyle, textAlign: "center", marginTop: "1rem" }}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {config.ctaText}
            </a>
          )}
        </nav>
      </div>
    </div>
  );
}

/**
 * Plug-and-Play Footer Component
 */
export function Footer({
  siteName,
  footerSettings = {},
  navigationLinks = [],
}) {
  const config = {
    bgColor: "#1a202c",
    textColor: "#a0aec0",
    borderTopColor: "#2d3748",
    copyright: `© ${new Date().getFullYear()} ${siteName}. All rights reserved.`,
    ...footerSettings,
  };

  const columns = config.columns || [];

  const footerStyle = {
    backgroundColor: config.bgColor || "#1a202c",
    color: config.textColor || "#a0aec0",
    padding: "3rem 1.5rem",
    borderTop: `1px solid ${config.borderTopColor || "#2d3748"}`,
  };

  const headingColor =
    config.textColor === "#a0aec0" ? "#ffffff" : config.textColor;
  const linkColor = config.textColor || "#a0aec0";

  const renderColumnContent = (col, idx) => {
    switch (col.type) {
      case "logo_desc":
        return (
          <div key={idx}>
            {col.logoUrl ? (
              <img
                src={col.logoUrl}
                alt="Logo"
                style={{
                  height: "40px",
                  objectFit: "contain",
                  marginBottom: "1rem",
                }}
              />
            ) : (
              <h4
                style={{
                  color: headingColor,
                  fontWeight: 700,
                  margin: "0 0 1rem 0",
                }}
              >
                {col.title || siteName}
              </h4>
            )}
            <p style={{ fontSize: "0.75rem", lineHeight: "1.6" }}>
              {col.description || ""}
            </p>
          </div>
        );

      case "links":
        return (
          <div key={idx}>
            <h5
              style={{
                color: headingColor,
                fontWeight: 700,
                fontSize: "0.875rem",
                margin: "0 0 0.75rem 0",
              }}
            >
              {col.title || "Links"}
            </h5>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "0.5rem",
                fontSize: "0.75rem",
              }}
            >
              {(col.links || []).map((link, i) => (
                <a
                  key={i}
                  href={link.url || "#"}
                  style={{ color: linkColor, textDecoration: "none" }}
                >
                  {link.label || link.text || link.name || "Link"}
                </a>
              ))}
            </div>
          </div>
        );

      case "contact":
        return (
          <div key={idx}>
            <h5
              style={{
                color: headingColor,
                fontWeight: 700,
                fontSize: "0.875rem",
                margin: "0 0 0.75rem 0",
              }}
            >
              {col.title || "Contact"}
            </h5>
            <div
              style={{
                fontSize: "0.75rem",
                lineHeight: "1.8",
                color: linkColor,
              }}
            >
              {col.phone && <p>📞 {col.phone}</p>}
              {col.email && <p>✉️ {col.email}</p>}
              {col.address && <p>📍 {col.address}</p>}
              {col.content && <p>{col.content}</p>}
            </div>
          </div>
        );

      case "newsletter": {
        const [nlEmail, setNlEmail] = React.useState("");
        const [nlStatus, setNlStatus] = React.useState("idle");
        const handleNlSubmit = async (e) => {
          e.preventDefault();
          if (!nlEmail.trim()) return;
          setNlStatus("submitting");
          try {
            const baseUrl =
              process.env.NEXT_PUBLIC_CMS_BASE_URL || "http://localhost:3000";
            const siteId =
              process.env.NEXT_PUBLIC_SITE_ID || "layman_litigation";
            await fetch(baseUrl + "/api/forms/submit", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                siteId,
                name: "Newsletter Subscriber",
                email: nlEmail,
                message: "Subscribed to newsletter from footer",
                _hp: "",
              }),
            });
            setNlStatus("success");
            setNlEmail("");
            setTimeout(() => setNlStatus("idle"), 3000);
          } catch {
            setNlStatus("error");
            setTimeout(() => setNlStatus("idle"), 3000);
          }
        };
        return (
          <form key={idx} onSubmit={handleNlSubmit}>
            <h5
              style={{
                color: headingColor,
                fontWeight: 700,
                fontSize: "0.875rem",
                margin: "0 0 0.75rem 0",
              }}
            >
              {col.title || "Newsletter"}
            </h5>
            <p
              style={{
                fontSize: "0.75rem",
                lineHeight: "1.6",
                color: linkColor,
                marginBottom: "0.75rem",
              }}
            >
              {col.description || "Stay updated with our latest news."}
            </p>
            <div style={{ display: "flex", gap: "0.375rem" }}>
              <input
                type="email"
                required
                value={nlEmail}
                onChange={(e) => setNlEmail(e.target.value)}
                placeholder={col.newsletterPlaceholder || "your@email.com"}
                style={{
                  flex: 1,
                  padding: "0.5rem 0.75rem",
                  fontSize: "0.75rem",
                  borderRadius: "6px",
                  border: "1px solid #4a5568",
                  backgroundColor: "transparent",
                  color: "inherit",
                  outline: "none",
                  minWidth: 0,
                }}
              />
              <button
                type="submit"
                disabled={nlStatus === "submitting"}
                style={{
                  padding: "0.5rem 0.75rem",
                  fontSize: "0.7rem",
                  fontWeight: 700,
                  borderRadius: "6px",
                  border: "none",
                  backgroundColor:
                    nlStatus === "success" ? "#22c55e" : "#d9b04f",
                  color: "#1a202c",
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                  opacity: nlStatus === "submitting" ? 0.7 : 1,
                }}
              >
                {nlStatus === "success"
                  ? "Subscribed!"
                  : nlStatus === "submitting"
                    ? "..."
                    : col.newsletterButtonText || "Subscribe"}
              </button>
            </div>
            {nlStatus === "error" && (
              <p
                style={{
                  fontSize: "0.65rem",
                  color: "#ef4444",
                  marginTop: "0.375rem",
                }}
              >
                Subscription failed. Try again.
              </p>
            )}
          </form>
        );
      }

      default:
        return (
          <div key={idx}>
            <h5
              style={{
                color: headingColor,
                fontWeight: 700,
                fontSize: "0.875rem",
                margin: "0 0 0.75rem 0",
              }}
            >
              {col.title || ""}
            </h5>
            {col.content && (
              <p style={{ fontSize: "0.75rem", color: linkColor }}>
                {col.content}
              </p>
            )}
          </div>
        );
    }
  };

  return (
    <>
      <style>{`
        .sdk-footer-grid {
          grid-template-columns: 1fr !important;
        }
        @media (min-width: 640px) {
          .sdk-footer-grid {
            grid-template-columns: repeat(2, 1fr) !important;
          }
        }
        @media (min-width: 1024px) {
          .sdk-footer-grid {
            grid-template-columns: repeat(${Math.min(columns.length || 4, 4)}, minmax(200px, 1fr)) !important;
          }
        }
      `}</style>
      <footer style={footerStyle}>
        <div
          className="sdk-footer-grid"
          style={{
            maxWidth: "80rem",
            margin: "0 auto",
            display: "grid",
            gridTemplateColumns: `repeat(${Math.min(columns.length || 4, 4)}, minmax(200px, 1fr))`,
            gap: "2rem",
          }}
        >
          {columns.length > 0 ? (
            columns.map((col, idx) => renderColumnContent(col, idx))
          ) : (
            <>
              <div>
                <h4
                  style={{
                    color: headingColor,
                    fontWeight: 700,
                    margin: "0 0 1rem 0",
                  }}
                >
                  {siteName}
                </h4>
                <p style={{ fontSize: "0.75rem", lineHeight: "1.6" }}>
                  High-performance modular pages served dynamically via backend
                  integrations.
                </p>
              </div>
              <div>
                <h5
                  style={{
                    color: headingColor,
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    margin: "0 0 0.75rem 0",
                  }}
                >
                  Navigation
                </h5>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "0.5rem",
                    fontSize: "0.75rem",
                  }}
                >
                  {navigationLinks.slice(0, 4).map((link, idx) => (
                    <a
                      key={idx}
                      href={link.url}
                      style={{ color: "inherit", textDecoration: "none" }}
                    >
                      {link.label}
                    </a>
                  ))}
                </div>
              </div>
              <div>
                <h5
                  style={{
                    color: headingColor,
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    margin: "0 0 0.75rem 0",
                  }}
                >
                  Connection
                </h5>
                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "0.375rem",
                    borderRadius: "9999px",
                    backgroundColor: "#064e3b",
                    padding: "0.25rem 0.625rem",
                    fontSize: "0.7rem",
                    fontWeight: 700,
                    color: "#34d399",
                    border: "1px solid #065f46",
                  }}
                >
                  CONNECTED
                </span>
              </div>
              <div>
                <h5
                  style={{
                    color: headingColor,
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    margin: "0 0 0.75rem 0",
                  }}
                >
                  Copyright
                </h5>
                <p style={{ fontSize: "0.7rem", lineHeight: "1.6" }}>
                  {config.copyright}
                </p>
              </div>
            </>
          )}
        </div>
        <div
          style={{
            maxWidth: "80rem",
            margin: "2rem auto 0",
            paddingTop: "1.5rem",
            borderTop: "1px solid rgba(255,255,255,0.1)",
            textAlign: "center",
            fontSize: "0.7rem",
            color: linkColor,
          }}
        >
          {config.copyright}
        </div>
      </footer>
    </>
  );
}

// ... existing code (GlobalAnalytics, Header, Footer) ...

/**
 * RichTextRenderer Component
 * Takes raw HTML from the CMS (like BlockNote output), sanitizes it to prevent XSS,
 * and renders it beautifully using standard typography classes.
 */
export function RichTextRenderer({ content, className = "" }) {
  const [cleanHtml, setCleanHtml] = useState(typeof content === "string" ? content : "");

  useEffect(() => {
    if (content) {
      const htmlString = typeof content === "string" ? content : String(content);
      import("dompurify").then((module) => {
        const DOMPurify = module.default || module;
        setCleanHtml(DOMPurify.sanitize(htmlString));
      });
    }
  }, [content]);

  if (!content) return null;

  return (
    <div
      className={`prose prose-slate prose-lg max-w-none space-y-4 ${className}`}
      dangerouslySetInnerHTML={{ __html: cleanHtml }}
    />
  );
}

/**
 * OneSignalScript Component
 * Loads and initializes OneSignal on the client website.
 */
export function OneSignalScript({ settings }) {
  if (!settings) return null;
  const emailSettings = settings.emailSettings || {};
  const appId = settings.oneSignalAppId || emailSettings.oneSignalAppId;
  if (!appId) return null;

  return (
    <Script
      id="onesignal-init-script"
      src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js"
      defer
      strategy="afterInteractive"
      onLoad={() => {
        window.OneSignal = window.OneSignal || [];
        window.OneSignal.push(function () {
          window.OneSignal.init({
            appId: appId,
            safari_web_id: emailSettings.oneSignalSafariWebId || undefined,
            notifyButton: {
              enable: true,
            },
          });
        });
      }}
    />
  );
}

